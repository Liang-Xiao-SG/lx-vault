---
layout: post
author: liangxiao
---

**管理为何不能说**  

### Purpose: ###
  using cost of 3 people , let 2 people do 4 people job
Key: 
  Maximize effective job - Effective 
Management is a skill can not be describe 
as organization scales, the information will be
- distort
- overload
- interference 

Two Type of jobs: 
- measurable job
- unmesurable job

One right :
- ### the right to apprasial ###
> 👉 [阅读全文](https://www.huxiu.com/article/4432138.html)