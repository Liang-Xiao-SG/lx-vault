---
layout: post
author: liangxiao
---

### Benefits
Learn to output is the only way to contribute to a secondary medium

Building blog can collect thoughts
- a great way to expose 
- share usful info 
- attract common interest
  

